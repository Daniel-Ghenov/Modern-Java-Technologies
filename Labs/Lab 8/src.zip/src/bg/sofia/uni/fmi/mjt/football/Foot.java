package bg.sofia.uni.fmi.mjt.football;

public enum Foot {
    LEFT, RIGHT;
}