package com.doge.torrent.utils;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class Constants {

	public static final int PIECE_SIZE = 16384;
	public static final Charset DEFAULT_CHARSET = StandardCharsets.ISO_8859_1;

}
