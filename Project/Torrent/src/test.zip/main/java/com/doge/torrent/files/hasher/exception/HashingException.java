package com.doge.torrent.files.hasher.exception;

public class HashingException extends RuntimeException {

	public HashingException(Throwable cause) {
		super(cause);
	}
}
