package com.doge.torrent.connection.message;

public class HandshakeException extends RuntimeException {
	public HandshakeException(String message) {
		super(message);
	}
}
