package com.doge.torrent.download.files;

public interface TorrentSaver {

	void save(byte[] data);
}
