package bg.sofia.uni.fmi.mjt.itinerary;

public record Location(int x, int y) {
}