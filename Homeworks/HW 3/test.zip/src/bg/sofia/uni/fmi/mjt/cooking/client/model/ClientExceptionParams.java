package bg.sofia.uni.fmi.mjt.cooking.client.model;

public record ClientExceptionParams(

		String error,
		String property
) {

}
